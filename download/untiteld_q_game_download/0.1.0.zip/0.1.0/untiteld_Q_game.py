import os
import json
import random

money = 0
casino_chip = 0
super_casino_chip = 0
value_casino_chip = 25
value_super_casino_chip = 100
inventory = None
main_input_info = "1. level select\n2. free play\n3. main_menu\n4. quit"
savedata = None
container_all_stats = None
levels = "(1)Free INFINIYY levels\n(2)Custom levels\n(3)DLC levels\n(4)Main menu\n(5)Quit"

#custom
questions = None
anwsers = None
run_commands = None

def mod_decoder(save_name, mod_name):
    global questions
    global anwsers
    global run_commands
    with open("./data/saves/" + save_name + "/mods/" + mod_name + ".json", "r") as mod:
        load = json.loads(mod.read())
    questions = load["main"]["data"]["questions"]
    anwsers = load["main"]["data"]["answers"]
    run_commands = load["main"]["command"]

def command_compiler():
    #custom_text
    question_correct_text = "correct"
    question_wrong_text = "wrong!"
    all_good_text = [
        "good job!", "well done!", "fantasic!", "Ez!"
    ]
    out_of_trys_text = [
        "maybe next time!", "you can do better i know it!", "maybe better next time!", "come on! you can do better"
    ]
    #other
    wrong = 0
    brake_q = False
    global questions
    global anwsers
    global run_commands
    start = False
    order = []
    trys = 1
    end = True
    skipper_1 = False
    run_order = False

    #read

    output_ram_1 = None
    output_ram_2 = None
    y = run_commands
    for i in range(len(y)):
        output_ram_1 = None
        output_ram_2 = None
        # .order= <order>
        if y[i][0] == "." and y[i][1] == "o" and y[i][2] == "r" and y[i][3] == "d" and y[i][4] == "e" and y[i][5] == "r" and y[i][6] == "=":
            output_ram_1 = ""
            for x in range(len(y[i])-len(".order=")):
                output_ram_1 += y[i][x+len(".order=")]
            for i in range(len(output_ram_1)):
                if not skipper_1:
                    #fix
                    if not output_ram_1[i] == ",":
                        try:
                            if not output_ram_1[i+1] == ",":
                                order.append(output_ram_1[i]+output_ram_1[i+1])
                                skipper_1 = True
                            else:
                                order.append(output_ram_1[i])
                        except IndexError:
                            order.append(output_ram_1[i])
        # .correcttext=
        elif y[i][0] == "." and y[i][1] == "c" and y[i][2] == "o" and y[i][3] == "r" and y[i][4] == "r" and y[i][5] == "e" and y[i][6] == "c" and y[i][7] == "t" and y[i][8] == "t" and y[i][9] == "e" and y[i][10] == "x" and y[i][11] == "t" and y[i][12] == "=":
            output_ram_1 = ""
            question_correct_text = ""
            for z in range(len(y[i])-len(".correcttext=")):
                output_ram_1 += y[i][z+len(".correcttext=")]
            question_correct_text = output_ram_1
        # .wrongtext=
        elif y[i][0] == "." and y[i][1] == "w" and y[i][2] == "r" and y[i][3] == "o" and y[i][4] == "n" and y[i][5] == "g" and y[i][6] == "t" and y[i][7] == "e" and y[i][8] == "x" and y[i][9] == "t" and y[i][10] == "=":
            output_ram_1 = ""
            question_wrong_text = ""
            for z in range(len(y[i])-len(".wrongtext=")):
                output_ram_1 += y[i][z+len(".wrongtext=")]
            question_wrong_text = output_ram_1
        elif y[i] == ".start":
            start = True
        elif y[i] == ".end":
            end = False
        # .trys= <amount>
        elif y[i][0] == "." and y[i][1] == "t" and y[i][2] == "r" and y[i][3] == "y" and y[i][4] == "s" and y[i][5] == "=":
            output_ram_1 = ""
            for x in range(len(y[i])-len(".trys=")):
                output_ram_1 += y[i][x+len(".trys=")]
            trys = int(output_ram_1)

    #compile

    for x in range(len(y)):
        if brake_q:
            break
        if start == True:
            if end == True:
                print("The End")
                break
            if y[x] == ".end":
                end = True
            if order != "":
                run_order = True
        else:
            break

    # .load=.mods=mod_test
    if order == ["no"]:
        order = []
        for x in range(len(questions)):
            order.append(str(x+1))
    if run_order:
        for x in range(len(order)):
            wrong = 0
            while wrong != trys:
                print(questions[x])
                input_question = input("> ")
                if input_question.lower() == anwsers[x].lower():
                    print(question_correct_text)
                    break
                else:
                    print(question_wrong_text)
                    wrong += 1
    if wrong == trys:
        print(random.choice(out_of_trys_text))
    else:
        print(random.choice(all_good_text))

def print_stats():
    global money
    global casino_chip
    global super_casino_chip
    print("money: " + str(money))
    if not casino_chip <= 0:
        print("casino chips: " + str(casino_chip))
    if not super_casino_chip <= 0:
        print("super casino chips: " + str(super_casino_chip))

def save_stats():
    global container_all_stats
    global money
    global inventory
    container_all_stats["stats"]["money"] = money
    container_all_stats["stats"]["inventory"] = inventory
    with open("./data/saves/" + container_all_stats["stats"]["save_name"] + "/stats.json", "w") as save_stats_data:
        save_stats_data.write(json.dumps(container_all_stats, indent=2))

def loadconfigdata():
    global savedata
    with open("./data/config.json", "r") as config:
        savedata = json.loads(config.read())


def reload_configFile():
    global savedata
    with open("./data/config.json", "w") as config:
        config.write(json.dumps(savedata, indent=2))

def load_save(save_name):
    global money
    global inventory
    global container_all_stats
    with open("./data/saves/" + save_name + "/stats.json", "r") as load:
        load = json.loads(load.read())
    container_all_stats = load
    savedata["save_data"]["recent"] = save_name
    money = load["stats"]["money"]
    inventory = load["stats"]["inventory"]
    reload_configFile()

def level_selector():
    global levels
    print(levels)
    inputLvls = int(input("select level\n> "))
    if inputLvls == 1:
        level_hard()
    elif inputLvls == 2:
        pass
    elif inputLvls == 3:
        pass
    elif inputLvls == 4:
        main_menu()
    elif inputLvls == 5:
        quit()

def level_1():
    global money
    global inventory
    questions = ["a spider has 6 eyes", "how many sides has a dice", "In which month does spring begin", "How many hours is a week", "What Roman god is the month of March named after", "What color are the hearts and diamonds in a deck of cards", "how many legs does a cat has", "In addition to clay, ore, grain, and wood, what resource can you receive in the Settlers of Catan board game", "What color is money proverbially when no tax has been paid on it", "what animals are humans most afraid of"]
    anwsers = [False, 6, "march", "168 hours", "Mars", "red", 4, "wool", "black", "spider"]
    level_1_input_1 = input("")

def level_hard():
    global money
    questions = [
        "What are two things you can never eat for breakfast",
        "What is always coming but never arrives",
        "What never asks a question but gets answered all the time",
        "A girl fell off a 50-foot ladder but didn’t get hurt. How come",
        "If you have one, you want to share it. But once you share it, you do not have it. What is it",
        "What starts with “e” and ends with “e” but only has one letter in it",
        "If a plane crashes on the border between the United States and Canada, where do they bury the survivors",
        "How can a girl go 25 days without sleep",
        "If it takes eight men ten hours to build a wall, how long would it take four men",
        "If you have a bowl with six apples and you take away four, how many do you have",
        "If Mrs. John’s one-story house is decorated completely in pink, with the walls, carpet, and furniture all shades of pink, what color are the stairs",
        "How did the boy kick his soccer ball ten feet, and then have it come back to him on its own",
        "A young boy was rushed to the hospital emergency room, but the ER doctor saw the boy and refused to operate. “This boy is my son,” the doctor said. But the doctor wasn’t the boy’s father. How could this be",
        "How could a man go outside in the pouring rain without protection, and not have a hair on his head get wet",
        "What has a face and two hands, but no arms or legs",
        "str = 1+1=",
        "there are 11 sheeps how many are when 1 one cow jumps over the fence",
        "What is the answer to this question",
        "What’s something that copies your looks but not your sounds",
        "I wave, even if you don’t say hello. What am I",
        "Two is a duo, and three is a trio. So what do four and five make",
        "How many times can you cut a cake in half",
        "What’s something you can you hold without touching it",
        "If you were in a race and passed the person in third place, what place would you be in"

    ]
    anwsers = ["Lunch and Dinner", "Tomorrow", "Your cellphone", "She fell off the bottom step", "A secret", "An envelope", "Survivors aren’t buried!", "She sleeps at night", "No time, because the wall is already built", "The four you took", "There are no stairs", "He kicked it up", "The doctor was the boy’s mom", "He is bald", "A clock", "11", "11", "What?", "A mirror", "a flag", "Nine", "once", "Your breath", "Third place"]
    trys = 0
    questions_correct = 0
    multi_plier = 0.1
    while True:
        trys = 0
        random_question_picker = random.choice(questions)
        while trys != 3:
            question_number = 0
            print("press 1 or . to quit\n" + random_question_picker)
            input_player = input("> ")
            for i in range(len(questions)):
                if random_question_picker == questions[i]:
                    question_number = i
            print(input_player)
            if input_player == "1" or input_player == ".":
                level_selector()
            elif input_player.lower() == anwsers[question_number].lower():
                print("correct")
                add_money = int(7500*(multi_plier*(questions_correct+1)))
                money += add_money
                print("added " + str(add_money) + " money")
                break
            else:
                trys += 1
                print("try again, got " + str(3-trys) +"/3 trys left")
        if trys == 3:
            print(anwsers[question_number].lower())

###CASINO###
def casino():
    global money
    global casino_chip
    global super_casino_chip
    global value_casino_chip
    global value_super_casino_chip
    casino_options = "(1)Change currency\n(2)play \"Win\" Or Lose\n(3)Main Menu\n(4)Quit\n"
    print(casino_options)

    input_casino = int(input("> "))
    if input_casino == 1:
        input_casino_change_currenctie = input("money > casino chips | casino chips > money | 1/2: ")
        if input_casino_change_currenctie == "1":
            input_how_much = int(input("25 money = 1 casino chip | amount of casino chips: "))
            checker_1 = input_how_much * value_casino_chip
            if checker_1 <= money:
                money -= checker_1
                save_stats()
            else:
                print("you need " + str(abs(checker_1-money)) + " more money")



def Gamble():
    options = "(1)Casino\n(2)Leave Mode\n(3)Main menu\n(4)Quit\n"
    select_input_Gamble = int(input(options + "> "))
    if select_input_Gamble == 1:
        casino()
    elif select_input_Gamble == 2:
        freePlay()
    elif select_input_Gamble == 3:
        main_menu()
    elif select_input_Gamble == 4:
        quit()
###CASINO###


def freePlay():
    global money
    global inventory

    what_do_question = "(1)Gamble\n(2)Shop\n(3)Company\n(4)Command_input\n(5)Leave Free play\n(6)Main menu\n(7)Quit\n"
    while True:
        print_stats()
        free_play_input_main = int(input(what_do_question + "> "))
        if free_play_input_main == 1:
            Gamble()
        elif free_play_input_main == 2:
            pass
        elif free_play_input_main == 3:
            pass
        elif free_play_input_main == 4:
            command_line_or_console()
        elif free_play_input_main == 5:
            main_loop()
        elif free_play_input_main == 6:
            main_menu()
        elif free_play_input_main == 7:
            quit()

def main_loop():
    while True:
        print_stats()
        try:
            # os.system("clear")
            main_game_input = int(input(main_input_info + "\n> "))
            if main_game_input == 1:
                level_selector()
            elif main_game_input == 2:
                freePlay()
                break
            elif main_game_input == 3:
                main_menu()
                break
            elif main_game_input == 4:
                quit()
            elif main_game_input == 666:
                quit()
        except ValueError:
            pass

def command_line_or_console():
    global money
    global inventory
    global container_all_stats
    # main = ic[0] == ""
    while True:
        try:
            output = ""
            ic = input(">>> ").lower()
            if ic[0] == "." and ic[1] == "s" and ic[2] == "a" and ic[3] == "y" and ic[4] == " ":
                for i in range(len(ic)-5):
                    output += ic[i+5]
                if output == ".stats=money":
                    print(money)
                elif output == ".stats=inventory":
                    if inventory == []:
                        print("empty")
                    else:
                        print(inventory)
                elif output == ".stats=container":
                    print(container_all_stats)
                else:
                    print(output)
            elif ic == ".save data":
                save_stats()
                print("saved stats")
            # .load=.mods=

            elif ic[0] == "." and ic[1] == "l" and ic[2] == "o" and ic[3] == "a" and ic[4] == "d" and ic[5] == "=":
                for i in range(len(ic)-len(".load=")):
                    output += ic[i+len(".load=")]
                if output == ".main_menu":
                    main_menu()
                if output == ".game_select":
                    main_loop()
                if output == ".level_select":
                    level_selector()
                if output == ".free_play=menu":
                    freePlay()
                if output == ".free_play=gamble":
                    Gamble()
                if output == ".quit_game":
                    quit()
                if output == ".mod_studio":
                    # mod studio load
                    pass
                if output[0] == "." and output[1] == "m" and output[2] == "o" and output[3] == "d" and output[4] == "s" and output[5] == "=":
                    output = ""
                    for i in range(len(ic) - len(".load=.mods=")):
                        output += ic[i + len(".load=.mods=")]
                    mod_decoder(container_all_stats["stats"]["save_name"], output)
                    command_compiler()
                    print(output)
            # elif ic == ".stats money=":
            elif ic[0] == "." and ic[1] == "s" and ic[2] == "t" and ic[3] == "a" and ic[4] == "t" and ic[5] == "s" and ic[6] == " " and ic[7] == "m" and ic[8] == "o" and ic[9] == "n" and ic[10] == "e" and ic[11] == "y" and ic[12] == "=":
                for i in range(len(ic)-13):
                    output += ic[i+13]
                money = int(output)
                print("money set to " + str(money))
            elif ic[0] == "." and ic[1] == "s" and ic[2] == "t" and ic[3] == "a" and ic[4] == "t" and ic[5] == "s" and ic[6] == " " and ic[7] == "m" and ic[8] == "o" and ic[9] == "n" and ic[10] == "e" and ic[11] == "y" and ic[12] == "+" and ic[13] == "=":
                for i in range(len(ic)-14):
                    output += ic[i+14]
                money += int(output)
                print("added " + str(money) + " money")
            else:
                print("ERROR::\"compiler error\"::ERROR")
        except IndexError:
            print("ERROR::\"compiler error\"::ERROR")



def main_menu():
    while True:
        loadconfigdata()
        main_menu = "(1)Continue\n(2)New Game\n(3)Load Game\n(4)Options\n> "
        mainMenu_input = int(input(main_menu))
        if mainMenu_input == 2:
            def createSavFile(save_name):
                with open("./data/template.json", "r") as template_load:
                    worldTemplate = json.loads(template_load.read())
                worldTemplate["stats"]["save_name"] = save_name
                print(worldTemplate)
                with open("./data/saves/" + inputSavGameName + "/stats.json", "w") as stats:
                    stats.write(json.dumps(worldTemplate, indent=4))
            inputSavGameName = input("Save Name: ")
            try:
                os.makedirs("./data/saves/" + inputSavGameName + "/mods")
                createSavFile(inputSavGameName)
            except FileExistsError:
                inputAreShure = input("are you sure you want to overide this save file y/n")
                if inputAreShure[0] == "y":
                    createSavFile(inputSavGameName)
                else:
                    main_menu()
            load_save(inputSavGameName)
            main_loop()
            break
        elif mainMenu_input == 3:
            try:
                inputload = input("save name: ")
                load_save(inputload)
                main_loop()
                break
            except FileNotFoundError:
                print("no save named \"" + inputload + "\" ")
        elif mainMenu_input == 4:
            print("comming soon :)")

        elif mainMenu_input == 1:
            if not savedata["save_data"]["recent"] == "":
                load_save(savedata["save_data"]["recent"])

                main_loop()
                break
            else:
                print("no save was previous loaded")
        elif mainMenu_input == 5:
            print("bye :)")
            quit()
main_menu()

